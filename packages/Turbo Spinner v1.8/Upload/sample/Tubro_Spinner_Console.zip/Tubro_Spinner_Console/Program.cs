﻿using System;
using System.Diagnostics;
using System.Net;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string textToSpin = "Enter a article, need to spin......";
        string api_key = "Your-API-KEY";
        string serviceUri = "Your-API-URL";
        string lang = "en";

        string post_data = "api_key=" + api_key + "&article=" + textToSpin + "&lang=" + lang;

        // create a request
        HttpWebRequest request = (HttpWebRequest)
        WebRequest.Create(serviceUri); 
        request.Method = "POST";

        // turn our request string into a byte stream
        byte[] postBytes = System.Text.Encoding.ASCII.GetBytes(post_data);

        // this is important - make sure you specify type this way
        request.ContentType = "application/x-www-form-urlencoded";
        request.ContentLength = postBytes.Length;
        Stream requestStream = request.GetRequestStream();

        // now send it
        requestStream.Write(postBytes, 0, postBytes.Length);
        requestStream.Close();

        // grab te response and print it out to the console
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Console.WriteLine(new StreamReader(response.GetResponseStream()).ReadToEnd());
        Console.ReadLine();
    }
}