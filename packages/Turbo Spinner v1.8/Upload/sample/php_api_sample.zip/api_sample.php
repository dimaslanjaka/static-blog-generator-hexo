<?php
/*
 * @author Balaji
 */
error_reporting(1);
    
    $api_url = "";
    $api_key = "Your-API-Key";
    $article = "Enter a article, need to spin......";
    $lang="en";
    
    $cookie=tempnam("/tmp","CURLCOOKIE");
    $agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7";
    $ch = curl_init();
    
    $data = "api_key=$api_key&article=$article&lang=$lang";
    curl_setopt($ch, CURLOPT_URL,"$api_url");    
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch,CURLOPT_ENCODING,"gzip,deflate");
	curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: application/x-www-form-urlencoded","Accept: */*"));
	curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_REFERER, "http://prothemes.biz");
	curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS,"$data");
	$html=curl_exec($ch);
	$lastUrl = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    echo "<pre>$html</pre>";
?>